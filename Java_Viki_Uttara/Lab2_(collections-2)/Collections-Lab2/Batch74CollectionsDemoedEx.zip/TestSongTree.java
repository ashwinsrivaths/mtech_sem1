package com.uttara.test;

import java.util.Set;
import java.util.TreeSet;

public class TestSongTree {

	public static void main(String[] args) {
		
		Song s1 = new Song("hum dil de chuke sanam",12,3);
		Song s2 = new Song("chaiya chaiya",4,5);
		Song s3 = new Song("tum mile kya hua",6,2);
		Song s4 = new Song("tumko kuch kuch kyon hua",3,0);
		Song s5 = new Song("tumko kuch kuch kyon hua",3,0);
		Song s6 = new Song("tum tum tum ho gum gum gum",3,4);
		
		Set ts1 = new TreeSet();
		ts1.add(s1);
		ts1.add(s2);
		ts1.add(s3);
		ts1.add(s4);
		ts1.add(s5);
		ts1.add(s6);
		
		System.out.println("ts1 = "+ts1);
		
		SongNameComparator comp1 = new SongNameComparator();
		Set ts2 = new TreeSet(comp1);
		ts2.add(s1);
		ts2.add(s2);
		ts2.add(s3);
		ts2.add(s4);
		ts2.add(s5);
		
		System.out.println("ts2 = "+ts2);

	}

}
