package com.uttara.test;

import java.util.Set;
import java.util.TreeSet;

public class TestStringTree {

	public static void main(String[] args) {
		
		String s1 = "dosa";
		String s2 = "idly";
		String s3 = "uppittu";
		String s4 = "puliogre";
		String s5 = "uttappam";
		String s6 = "appam";
		
		Set ts = new TreeSet();
		ts.add(s1);
		ts.add(s2);
		ts.add(s3);
		ts.add(s4);
		ts.add(s5);
		ts.add(s6);
		
		System.out.println(ts);

		StringLengthCompator slc = new StringLengthCompator();
		Set lts = new TreeSet(slc);
		lts.add(s1);
		lts.add(s2);
		lts.add(s3);
		lts.add(s4);
		lts.add(s5);
		lts.add(s6);
		
		System.out.println("lts = "+lts);
		
		StringVowelComparator svc = new StringVowelComparator();
		Set vts = new TreeSet(svc);
		vts.add(s1);
		vts.add(s2);
		vts.add(s3);
		vts.add(s4);
		vts.add(s5);
		vts.add(s6);
		//vts.add(null);
		
		System.out.println("vts = "+vts);
	}

}
