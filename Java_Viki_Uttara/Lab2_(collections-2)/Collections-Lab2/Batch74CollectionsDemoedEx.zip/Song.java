package com.uttara.test;

public class Song implements Comparable{
	
	private String name;
	private int length;
	private int rating;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	
	public Song(String name, int length, int rating) {
		super();
		this.name = name;
		this.length = length;
		this.rating = rating;
	}
	
	public Song() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if(obj instanceof Song)
		{
			Song s = (Song) obj;
			
			if(this.name.equals(s.name) && this.length == s.length && this.rating == s.rating)
				return true;
			else
				return false;
		}
		else
			return false;
	}
	
	@Override
	public String toString() {
		return "Song:name="+name+",length="+length+",rating="+rating;
	}
	
	@Override
	public int hashCode() {
		
		return (name + rating + length).hashCode();
	}
	
	@Override
	public int compareTo(Object o) {
		
		if(o instanceof Song)
		{
			Song s = (Song) o;
			if (this.length == s.length)
				return this.rating - s.rating;
			else
				return this.length - s.length;
		}
		else
			throw new IllegalArgumentException("only songs can be compared!");
	}
}







