package com.uttara.test;

public class TestCollectionsMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
