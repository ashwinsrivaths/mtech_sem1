package com.uttara.test;

public class Person {

	private String name;
	private int age;
	
	public Person() {
		// TODO Auto-generated constructor stub
	}
	
	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if(obj instanceof Person)
		{
			Person p = (Person) obj;
			if(this.name.equals(p.name) && this.age == p.age)
				return true;
			else
				return false;
		}
		else
			return false;
		
	}
	
	@Override
	public String toString() {
	
		return "Person:"+name+","+age;
	}
	
	@Override
	public int hashCode() {
		
		return (name + age).hashCode();
	}
	
}







