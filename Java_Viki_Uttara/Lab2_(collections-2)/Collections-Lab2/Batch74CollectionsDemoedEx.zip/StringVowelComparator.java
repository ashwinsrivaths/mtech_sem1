package com.uttara.test;

import java.util.Comparator;

public class StringVowelComparator implements Comparator {

	public static int numOfVowels(String str)
	{
		if(str==null)
			throw new IllegalArgumentException("string cannot be null!");
		
		int count = 0;
		str = str.toLowerCase();
		for(int i = 0 ; i < str.length() ; i++)
		{
			char c = str.charAt(i);
			if(c=='a' || c=='e' || c=='i'|| c=='o'|| c=='u')
				count++;
		}
		return count;
	}
	@Override
	public int compare(Object o1, Object o2) {
		if(o1 instanceof String && o2 instanceof String)
		{
			String s1 = (String) o1;
			String s2 = (String) o2;
			
			int count1 = StringVowelComparator.numOfVowels(s1);
			int count2 = StringVowelComparator.numOfVowels(s2);
			
			return count1 - count2;
		}
		else
			throw new IllegalArgumentException("only strings can be compared!");
	}
}
