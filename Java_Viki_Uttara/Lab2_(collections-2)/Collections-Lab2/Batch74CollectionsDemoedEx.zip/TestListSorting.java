package com.uttara.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class TestListSorting {

	public static void main(String[] args) {
		
		StringLengthCompator scomp1 = new StringLengthCompator();
		StringVowelComparator scomp2 = new StringVowelComparator();
		SongNameComparator songcomp1 = new SongNameComparator();
		
		List strings = new ArrayList();
		strings.add("rambo");
		strings.add("rocky");
		strings.add("kungu panda");
		strings.add("rambo2");
		strings.add("rocky2");
		strings.add("rambo");
		strings.add("rambo");
		strings.add("rambo");
		
		System.out.println("without sorting strings = "+strings);
		
		Collections.sort(strings);
		
		System.out.println("sorted with natural ord = "+strings);

		Collections.sort(strings,scomp1);
		
		System.out.println("sorted based on length = "+strings);
		
		Collections.sort(strings,scomp2);
		
		System.out.println("sorted based on vowels = "+strings);
		
		Song s1 = new Song("hum dil de chuke sanam",12,3);
		Song s2 = new Song("chaiya chaiya",4,5);
		Song s3 = new Song("tum mile kya hua",6,2);
		Song s4 = new Song("tumko kuch kuch kyon hua",3,0);
		Song s5 = new Song("tumko kuch kuch kyon hua",3,0);
		Song s6 = new Song("tum tum tum ho gum gum gum",3,4);

		List songs = new LinkedList();
		songs.add(s1);
		songs.add(s2);
		songs.add(s3);
		songs.add(s4);
		songs.add(s5);
		songs.add(s6);
		songs.add(s6);
		
		Collections.sort(songs);
		System.out.println("sorting songs based on natural ord "+songs);
		Collections.sort(songs,songcomp1);
		System.out.println("sorting songs based on name "+songs);
		
		Collections.sort(strings);
		System.out.println("sorted strings = "+strings);
		System.out.println("searching rambo using binary search = "+Collections.binarySearch(strings, "rambo"));
		System.out.println("before shuffling strings = "+strings);
		Collections.shuffle(strings);
		System.out.println("after shuffling strings = "+strings);
		
		int num = Collections.frequency(strings, "rambo");
		System.out.println("num of time rambo occurs = "+num);
		System.out.println("max of strings = "+Collections.max(strings));
	
	}

}
