package com.uttara.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class TestPersonSet {

	public static void main(String[] args) {
		
		Person p1 = new Person("Ramu",20);
		Person p2 = new Person("Ramu",20);
		System.out.println("is p1 == p2 ? "+(p1==p2));
		System.out.println("p1.equals(p2) ? "+p1.equals(p2));
		
		Collection col = new ArrayList();
		col.add(p1);
		System.out.println("checking if p2 exists in col "+col.contains(p2));
		
		System.out.println("p1 = "+p1);
		System.out.println("p2 = "+p2);
		System.out.println("p1.hashCode() = "+p1.hashCode());
		System.out.println("p2.hashCode() = "+p2.hashCode());
		
		Set hs = new HashSet();
		System.out.println("adding p1 into hs = "+hs.add(p1));
		System.out.println("adding p2 into hs = "+hs.add(p2));
		
	}

}
