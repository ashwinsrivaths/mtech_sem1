package com.uttara.test;

import java.util.Comparator;

public class SongNameComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		if(o1 instanceof Song && o2 instanceof Song)
		{
			
			Song s1 = (Song) o1;
			Song s2 = (Song) o2;
			
			return s1.getName().compareTo(s2.getName());
					
		}
		else
			throw new IllegalArgumentException("only songs can be compared!");
	}
}
